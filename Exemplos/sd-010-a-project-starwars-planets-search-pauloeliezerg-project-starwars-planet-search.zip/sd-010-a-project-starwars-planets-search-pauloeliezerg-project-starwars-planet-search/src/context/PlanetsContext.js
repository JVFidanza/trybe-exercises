import { createContext } from 'react';

const PlanetsContext = createContext();

export default PlanetsContext;
